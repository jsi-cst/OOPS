<?php

return [
    'updated' => 'The API key has been successfully generated'
];
