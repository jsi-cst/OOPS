<i {{ $attributes->merge(['class' => "{$prefix} fa-{$name} fa-fw"]) }} aria-hidden="true"></i>
