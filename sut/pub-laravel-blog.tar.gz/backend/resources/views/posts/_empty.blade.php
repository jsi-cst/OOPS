<x-alert type="info">
  @lang('posts.empty')
</x-alert>

