<x-turbo::frame id="comments">
    @each('comments/_comment', $comments, 'comment')
</x-turbo::frame>
