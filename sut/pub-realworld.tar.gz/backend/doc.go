/*
Golang Gonic/Gin startup project fork form RealWorld https://realworld.io

You can find all the spec and front end demo in the Realworld project

This project will include objects and relationships' CRUD, you will know how to write a golang/gin app though small perfectly formed.
*/
package main
