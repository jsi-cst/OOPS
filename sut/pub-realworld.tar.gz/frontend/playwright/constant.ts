export enum Route {
  Home = '/#/',
  Login = '/#/login',
  Register = '/#/register',
  Settings = '/#/settings',
  ArticleCreate = '/#/article/create',
  ArticleDetail = '/#/article/article-title',
}
