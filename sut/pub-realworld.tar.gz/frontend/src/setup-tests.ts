import '@testing-library/jest-dom/vitest'

// https://github.com/mswjs/msw/issues/1415#issuecomment-1650562700
location.href = 'https://api.realworld.show/'
