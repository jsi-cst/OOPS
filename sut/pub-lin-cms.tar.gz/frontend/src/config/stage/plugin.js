// 本文件是自动生成, 请勿修改
import custom from '@/plugin/custom/stage-config'
import linCmsUi from '@/plugin/lin-cms-ui/stage-config'

const pluginsConfig = [custom, linCmsUi]

export default pluginsConfig
