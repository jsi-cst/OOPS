import { useAdminProvide, useAdminInject } from './admin'

export { useAdminInject }

export const useProvide = () => {
  useAdminProvide()
}
