from .base import BaseConfig


class ProductionConfig(BaseConfig):
    """
    生产环境配置
    """

    pass
