# 本地文件上传相关配置模版
FILE = {
    "STORE_DIR": "assets",
    "SINGLE_LIMIT": 1024 * 1024 * 2,
    "TOTAL_LIMIT": 1024 * 1024 * 20,
    "NUMS": 10,
    "INCLUDE": set([]),
    "EXCLUDE": set([]),
}
