access_key = "not complete"
secret_key = "not complete"
bucket_name = "not complete"
token_expire_time = 3600
allowed_extensions = ["jpg", "gif", "png", "bmp"]
