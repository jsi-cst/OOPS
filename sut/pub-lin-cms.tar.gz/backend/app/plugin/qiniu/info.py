"""
:copyright: © 2020 by the Lin team.
:license: MIT, see LICENSE for more details.
"""

__name__ = "qiniu"
__version__ = "0.1.0"
__author__ = "Team Lin"
