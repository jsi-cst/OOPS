access_key_id = "not complete"
access_key_secret = "not complete"
endpoint = "http://oss-cn-shenzhen.aliyuncs.com"
bucket_name = "not complete"

upload_folder = "oss"
allowed_extensions = ["jpg", "gif", "png", "bmp"]
