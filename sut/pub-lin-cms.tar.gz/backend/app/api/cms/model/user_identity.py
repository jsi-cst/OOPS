from app.lin import UserIdentity as LinUserIdentity


class UserIdentity(LinUserIdentity):
    pass
